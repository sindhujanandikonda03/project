#include "main.h"										
#include "3ds.h"

#ifndef _LOAD3DS_H_
#define _LOAD3DS_H_

class Load3ds {
  private:
	CLoad3DS g_Load3ds;									
    t3DModel g_3DModel;	
	bool    initialized; 
	//GLuint  texture_obj;

  public:
    // Constructor. Can't do initialization here because we are
    // created before the OpenGL context is set up.
	  Load3ds(void) { initialized = false; };

    // Destructor. Frees the display lists and texture object.
    ~Load3ds(void);

    // Initializer. Creates the display list.
    bool    Initialize(void);

    // Does the drawing.
    void    Draw(void);
};


#endif
