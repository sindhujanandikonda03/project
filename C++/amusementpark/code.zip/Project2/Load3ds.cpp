/*
 * Ground.cpp: A class for drawing the ground.
 *
 * (c) 2001-2002: Stephen Chenney, University of Wisconsin at Madison.
 */

#include "main.h"
#include <stdio.h>
#include "3ds.h"
#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>
#include "Load3ds.h"

#define FILE_NAME  "Liberty.3ds"
#define MAX_TEXTURES 100

GLuint g_Texture[MAX_TEXTURES] = {0};

// Destructor
Load3ds::~Load3ds(void)
{
   if ( initialized ) {
	 for(int i = 0; i < g_3DModel.numOfObjects; i++)
	 {
		delete [] g_3DModel.pObject[i].pFaces;
		delete [] g_3DModel.pObject[i].pNormals;
		delete [] g_3DModel.pObject[i].pVerts;
		delete [] g_3DModel.pObject[i].pTexVerts;
	 }
    // glDeleteTextures(1, &texture_obj);
   }
}


// Initializer. Returns false if something went wrong, like not being able to
// load the texture.
bool
Load3ds::Initialize(void)
{
	// ubyte   *image_data;
  //   int	    image_height, image_width;

    // Load the image for the texture. The texture file has to be in
    // a place where it will be found.
/*    if ( ! ( image_data = (ubyte*)tga_load("Liberty.tga", &image_width,
					   &image_height, TGA_TRUECOLOR_24) ) )
    {
	fprintf(stderr, "Ground::Initialize: Couldn't load grass.tga\n");
	return false;
    }*/


	g_Load3ds.Import3DS(&g_3DModel, FILE_NAME);			

	for(int i = 0; i < g_3DModel.numOfMaterials; i++)
	{		
		if(strlen(g_3DModel.pMaterials[i].strFile) > 0)
		{
			
			CreateTexture(g_Texture, g_3DModel.pMaterials[i].strFile, i);
        /*    glGenTextures(1, &texture_obj);
            glBindTexture(GL_TEXTURE_2D, texture_obj);
            glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
            gluBuild2DMipmaps(GL_TEXTURE_2D,3, image_width, image_height, 
		                  GL_RGB, GL_UNSIGNED_BYTE, image_data);
	
            glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
	        glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR_MIPMAP_LINEAR);*/

		}

		g_3DModel.pMaterials[i].texureId = i;
	}

	glEnable(GL_LIGHT0);								
	glEnable(GL_LIGHTING);								
	glEnable(GL_COLOR_MATERIAL);
	initialized = true;

	return true;
}

// Draw just calls the display list we set up earlier.
void
Load3ds::Draw(void)
{
 
	//gluLookAt(		50,50, 50,		0, 0.5f, 0,			0, 1, 0);
	
	// ����ģ�������еĶ���
	for(int i = 0; i < g_3DModel.numOfObjects; i++)
	{
		// �������Ĵ�СС��0�����˳�
		if(g_3DModel.pObject.size() <= 0) break;

		// ��õ�ǰ��ʾ�Ķ���
		t3DObject *pObject = &g_3DModel.pObject[i];
			
		// �жϸö����Ƿ�������ӳ��
		if(pObject->bHasTexture) {

			// ������ӳ��
			glEnable(GL_TEXTURE_2D);
			glColor3ub(255, 255, 255);
			glBindTexture(GL_TEXTURE_2D, g_Texture[pObject->materialID]);
		} else {

			// �ر�����ӳ��
			glDisable(GL_TEXTURE_2D);
			glColor3ub(255, 255, 255);
		}
		// ��ʼ��g_ViewModeģʽ����
	glPushMatrix();
	    glScalef(0.3,0.3,0.3);
		glTranslatef(0,0,0);
		glBegin(GL_TRIANGLES);					
			// �������е���
			for(int j = 0; j < pObject->numOfFaces; j++)
			{
				// ���������ε����е�
				for(int whichVertex = 0; whichVertex < 3; whichVertex++)
				{
					// ������ÿ���������
					int index = pObject->pFaces[j].vertIndex[whichVertex];
			
					// ����������
					glNormal3f(pObject->pNormals[ index ].x, pObject->pNormals[ index ].y, pObject->pNormals[ index ].z);
				
					// ��������������
					if(pObject->bHasTexture) {

						// ȷ���Ƿ���UVW��������
						if(pObject->pTexVerts) {
							glTexCoord2f(pObject->pTexVerts[ index ].x, pObject->pTexVerts[ index ].y);
						}
					} else {

						if(g_3DModel.pMaterials.size() && pObject->materialID >= 0) 
						{
							BYTE *pColor = g_3DModel.pMaterials[pObject->materialID].color;
							glColor3ub(pColor[0], pColor[1], pColor[2]);
						}
					}
					glVertex3f(pObject->pVerts[ index ].x, pObject->pVerts[ index ].y, pObject->pVerts[ index ].z);
				}
			}

		glEnd();  // ���ƽ���
	      glPopMatrix();
	}

}


