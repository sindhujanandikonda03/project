/*
 * Ground.h: Header file for a class that draws the ground.
 *
 * (c) 2001-2002: Stephen Chenney, University of Wisconsin at Madison.
 */


#ifndef _SWEEP_H_
#define _SWEEP_H_

#include <Fl/gl.h>

typedef struct _Vertex {
    float   	    x[3];
    } Vertex;

class Sweep {
  private:
    GLubyte display_list;   // The display list that does all the work.
    GLuint  texture_obj;    // The object for the grass texture.
    bool    initialized;    // Whether or not we have been initialised.
	Vertex  *points;
  public:
    // Constructor. Can't do initialization here because we are
    // created before the OpenGL context is set up.
    Sweep(void) { display_list = 0; initialized = false; };

    // Destructor. Frees the display lists and texture object.
    ~Sweep(void);
    void DrawSegmentTextured(double x1, double y1, double nx1, double ny1, 
                        double x2, double y2, double nx2, double ny2,
                        double t1, double t2);

	void drawStar(float topRadius, float bottomRadius, Vertex *points, int sides);
    // Initializer. Creates the display list.
    bool    Initialize(void);

    // Does the drawing.
    void    Draw(void);
};


#endif
