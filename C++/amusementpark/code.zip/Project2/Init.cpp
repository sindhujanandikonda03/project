
#include "main.h"
#include "libtarga.h"

void CreateTexture(GLuint textureArray[], LPSTR strFileName, int textureID)
{
	 ubyte   *image_data;
	 int	    image_height, image_width;
	
	 if ( ! ( image_data = (ubyte*)tga_load(strFileName, &image_width,
					   &image_height, TGA_TRUECOLOR_24) ) )
    {
	fprintf(stderr, "Ground::Initialize: Couldn't load grass.tga\n");
    }

	// ��������
	glGenTextures(1, &textureArray[textureID]);

	// �������ض����ʽ
	glPixelStorei (GL_UNPACK_ALIGNMENT, 1);

	glBindTexture(GL_TEXTURE_2D, textureArray[textureID]);

	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, image_width, image_height, GL_RGB, GL_UNSIGNED_BYTE, image_data);

	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR_MIPMAP_NEAREST);
	glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR_MIPMAP_LINEAR);

}

