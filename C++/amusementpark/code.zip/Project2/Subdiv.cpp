/*
 * Sphere.cpp: Code for sphere generation
 *
 * (c) 2001 Stephen Chenney, University of Wisconsin at Madison
 */ 


#include "Subdiv.h"
#include <Fl/gl.h>
#include <stdlib.h>
#include <math.h>

#define X .525731112119133606
#define Z .850650808352039932
/*
static GLfloat vdata[12][3] = {
{-X, 0.0, Z}, {X, 0.0, Z}, {-X, 0.0, -Z}, {X, 0.0, -Z},
{0.0, Z, X}, {0.0, Z, -X}, {0.0, -Z, X}, {0.0, -Z, -X},
{Z, X, 0.0}, {-Z, X, 0.0}, {Z, -X, 0.0}, {-Z, -X, 0.0}
};

static GLfloat vdata[6][3] = {
{1, 0.0, 0}, {-1, 0.0,0}, {0, 1, 0}, {0, -1, 0},
{0.0, 0, 1}, {0.0, 0, -1}
};*/
static GLfloat vdata[8][3] = {
{1, 0.0, 0}, {-1, 0.0,0}, {0, 1, 0}, {0, -1, 0},
{0.0, 0, 0.1}, {-1,1,0},{1,1,0},{-1,0,1}
};
/*
static GLuint tindices[20][3] = {
{0,4,1}, {0,9,4}, {9,5,4}, {4,5,8}, {4,8,1},
{8,10,1}, {8,3,10}, {5,3,8}, {5,2,3}, {2,7,3},
{7,10,3}, {7,6,10}, {7,11,6}, {11,0,6}, {0,1,6},
{6,1,10}, {9,0,11}, {9,11,2}, {9,2,5}, {7,2,11} };*/

static GLuint tindices[15][3] = {
	{0,4,2}, {2,4,1}, {1,4,3}, {3,4,0}, {0,2,3}, {1,2,3}, {4,5,0}, {3,4,5},
	{7,6,2},{7,6,5},{7,6,3},{7,2,3},{7,1,3},{6,0,5},{6,0,2}
};
int i;

void normalize(float v[3]) {
GLfloat d = sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);

v[0] /= d; v[1] /= d; v[2] /= d;
}

void normcrossprod(float v1[3], float v2[3], float out[3])
{
GLint i, j;
GLfloat length;
out[0] = v1[1]*v2[2] - v1[2]*v2[1];
out[1] = v1[2]*v2[0] - v1[0]*v2[2];
out[2] = v1[0]*v2[1] - v1[1]*v2[0];
normalize(out);
}

void drawtriangle(float *v1, float *v2, float *v3)
{
   glTranslatef(2,0,0);
   glRotatef(90,1,0,0);
	glBegin(GL_TRIANGLES);
glNormal3fv(v1); glVertex3fv(v1);
glNormal3fv(v2); glVertex3fv(v2);
glNormal3fv(v3); glVertex3fv(v3);
glEnd();
}

Subdiv::Subdiv(void){}

Subdiv::~Subdiv(void)
{
    delete[] vertices;

}

bool Subdiv::Initialize()
{
    NumberOfDivisions = 0;
	return true;
   
}

void
Subdiv::Subdivide(float *v1,float *v2,float *v3,long depth)
{
   GLfloat v12[3], v23[3], v31[3];
   if (depth == 0) {
      glPushMatrix();
          drawtriangle(v1, v2, v3);
	   glPopMatrix();
         return;
}

for (int i = 0; i < 3; i++) {
v12[i] = (v1[i]+v2[i])/2;
v23[i] = (v2[i]+v3[i])/2;
v31[i] = (v3[i]+v1[i])/2;
}
normalize(v12);
normalize(v23);
normalize(v31);
Subdivide(v1, v12, v31, depth-1);
Subdivide(v2, v23, v12, depth-1);
Subdivide(v3, v31, v23, depth-1);
Subdivide(v12, v23, v31, depth-1);
}

void
Subdiv::Draw()
{

	for (i = 0; i < 15; i++) {
		Subdivide(&vdata[tindices[i][0]][0],
						&vdata[tindices[i][1]][0],
						&vdata[tindices[i][2]][0],NumberOfDivisions);
	}

  
}


