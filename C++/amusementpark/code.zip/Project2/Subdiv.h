/*
 * Sphere.h: Code for sphere generation
 *
 * (c) 2001 Stephen Chenney, University of Wisconsin at Madison
 */

#ifndef _SUBDIV_H_
#define _SUBDIV_H_

#include <stdio.h>
#include <math.h>

typedef struct _Vertex1 {
    float   	    x[3];
    } Vertex1;

class Subdiv {
  private:
    unsigned int    num_vertices;
    Vertex1  	    *vertices;
 
  public:
    int NumberOfDivisions;
    
	Subdiv(void) ;

    // Destructor. Frees the display lists and texture object.
    ~Subdiv(void);
	bool    Initialize(void);
    void    Subdivide(float *v1,float *v2,float *v3,long depth);
    void    Draw();
};

#endif
