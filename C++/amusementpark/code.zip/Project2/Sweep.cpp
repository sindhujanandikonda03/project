/*
 * Ground.cpp: A class for drawing the ground.
 *
 * (c) 2001-2002: Stephen Chenney, University of Wisconsin at Madison.
 */

#include "Sweep.h"
#include "libtarga.h"
#include <stdio.h>
#include <GL/glu.h>
#include <math.h>


#ifndef M_PI
#define M_PI 3.14159265
#endif

#define TWO_PI	(2*M_PI)

double list[9][4] = {
        {1.25, 1.25, 1.0, 0.},          // Vertex 1 x, y, normalx, normaly
        {1.257, 1.3125, 0.971555, -0.23682},            // 2
        {1.281,	1.375, 0.913121742,	-0.407686993},      // 3
        {1.313,	1.4375, 0.809620071,	-0.586954292},  // 4
        {1.375,	1.5, 0.709940842,	-0.704261316},      // 5
        {1.437,	1.5625, 0.77695496,	-0.629556185},      // 6
        {1.478,	1.625, 0.914874385,	-0.403738603},      // 7
        {1.494,	1.6875, 0.985044851,	-0.172298119},  // 8
        {1.5, 1.75, 1.0, 0.}};          // 9



int zoom = 0;
int pointsNum = 10;

void Sweep::drawStar(float topRadius, float bottomRadius, Vertex *points, int sides) {
	glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBindTexture(GL_TEXTURE_2D, texture_obj);

    if(pointsNum >= 2){  
      float angle = 0;
      float angleIncrement = TWO_PI / sides;

      //begin draw segments between caps
      angle = 0;
      for(int i = 1; i < pointsNum ; ++i){
        
		glBegin(GL_QUAD_STRIP);
		  //glTranslatef(0,0,10);
        for(int j = 0; j < sides + 1; j++){
		  glTexCoord2d(double(j) / sides, 0.666 + double(j) / 8 * 0.333);
		   glNormal3f(points[i].x[0] + cos(angle) * bottomRadius, points[i].x[1], points[i].x[2] + sin(angle) * bottomRadius);
          glVertex3f(points[i-1].x[0]+5 + cos(angle) * topRadius, points[i-1].x[1]+5, points[i-1].x[2] + sin(angle) * topRadius+5 );
		   glTexCoord2d(double(j) / sides, 0.666 + double(j+1) / 8 * 0.333);
		   glNormal3f(points[i-1].x[0] + cos(angle) * topRadius, points[i-1].x[1], points[i-1].x[2] + sin(angle) * topRadius);
          glVertex3f(points[i].x[0]+5 + cos(angle) * bottomRadius, points[i].x[1]+5, points[i].x[2] + sin(angle) * bottomRadius+5);

          angle += angleIncrement;
          }
        glEnd();
      }
      //begin draw segments between caps
    
  }
}



// Destructor
Sweep::~Sweep(void)
{
    if ( initialized )
    {
	glDeleteLists(display_list, 1);
	glDeleteTextures(1, &texture_obj);
    }
}


// Initializer. Returns false if something went wrong, like not being able to
// load the texture.
bool
Sweep::Initialize(void)
{
    ubyte   *image_data;
    int	    image_height, image_width;

	points = new Vertex[pointsNum + 1];

    // Load the image for the texture. The texture file has to be in
    // a place where it will be found.
    if ( ! ( image_data = (ubyte*)tga_load("grass.tga", &image_width,
					   &image_height, TGA_TRUECOLOR_24) ) )
    {
	fprintf(stderr, "Ground::Initialize: Couldn't load grass.tga\n");
	return false;
    }

    // This creates a texture object and binds it, so the next few operations
    // apply to this texture.
    glGenTextures(1, &texture_obj);
    glBindTexture(GL_TEXTURE_2D, texture_obj);

    // This sets a parameter for how the texture is loaded and interpreted.
    // basically, it says that the data is packed tightly in the image array.
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    // This sets up the texture with high quality filtering. First it builds
    // mipmaps from the image data, then it sets the filtering parameters
    // and the wrapping parameters. We want the grass to be repeated over the
    // ground.
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, image_width, image_height, 
		      GL_RGB, GL_UNSIGNED_BYTE, image_data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
		    GL_NEAREST_MIPMAP_LINEAR);

    // This says what to do with the texture. Modulate will multiply the
    // texture by the underlying color.
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); 

    // Now do the geometry. Create the display list.
    display_list = glGenLists(1);
    glNewList(display_list, GL_COMPILE);
	// Use white, because the texture supplies the color.
	glColor3f(1.0, 1.0, 1.0);

	// The surface normal is up for the ground.
	glNormal3f(0.0, 0.0, 1.0);

	// Turn on texturing and bind the grass texture.
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture_obj);

	// Draw the ground as a quadrilateral, specifying texture coordinates.
	glBegin(GL_QUADS);
	    glTexCoord2f(100.0, 100.0);
	    glVertex3f(50.0, 50.0, 0.0);
	    glTexCoord2f(-100.0, 100.0);
	    glVertex3f(-50.0, 50.0, 0.0);
	    glTexCoord2f(-100.0, -100.0);
	    glVertex3f(-50.0, -50.0, 0.0);
	    glTexCoord2f(100.0, -100.0);
	    glVertex3f(50.0, -50.0, 0.0);
	glEnd();

	// Turn texturing off again, because we don't want everything else to
	// be textured.
	glDisable(GL_TEXTURE_2D);
    glEndList();

    // We only do all this stuff once, when the GL context is first set up.
    initialized = true;

    return true;
}

void Sweep::DrawSegmentTextured(double x1, double y1, double nx1, double ny1, 
                        double x2, double y2, double nx2, double ny2,
                        double t1, double t2)
{
    glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBindTexture(GL_TEXTURE_2D, texture_obj);

    // We'll do 32 segments
    const int N = 32;
    double rs = TWO_PI / N;    // 2 * PI / N
	//double rs = 20; 
    double r1 = 0;          // The first angle
    double r2 = rs;         // The second angle

    double sin1 = sin(r1);
    double cos1 = cos(r1);
    double sin2, cos2;

    for(int i=0;  i<N;  i++, r1+=rs, r2+=rs, sin1=sin2, cos1=cos2)
    {
        // Compute the other angles
        sin2 = sin(r2);
        cos2 = cos(r2);

        // The four points and four normals we'll need
/*		double p1[3] = {x1 * cos1+3, 0, x1 * -sin1 +3}; 
        double n1[3] = {nx1 * cos1+3,0, nx1 * -sin1 +3}; 
        double p2[3] = {x1 * cos2+3, 0, x1 * -sin2+3}; 
        double n2[3] = {nx1 * cos2+3,0, nx1 * -sin2+3}; 
        double p3[3] = {x2 * cos2+3, 2, x2 * -sin2+3}; 
        double n3[3] = {nx2 * cos2+3,2, nx2 * -sin2+3}; 
        double p4[3] = {x2 * cos1+3, 2, x2 * -sin1+3}; 
        double n4[3] = {nx2 * cos1+3, 2, nx2 * -sin1+3};*/

        double p1[3] = {x1 * cos1, y1, x1 * -sin1}; 
        double n1[3] = {nx1 * cos1, ny1, nx1 * -sin1}; 
        double p2[3] = {x1 * cos2, y1, x1 * -sin2}; 
        double n2[3] = {nx1 * cos2, ny1, nx1 * -sin2}; 
        double p3[3] = {x2 * cos2, y2, x2 * -sin2}; 
        double n3[3] = {nx2 * cos2, ny2, nx2 * -sin2}; 
        double p4[3] = {x2 * cos1, y2, x2 * -sin1}; 
        double n4[3] = {nx2 * cos1, ny2, nx2 * -sin1}; 
	/*	double p1[3] = {x1 * cos1 - y1 * sin1, x1 * sin1 + y1 * cos1,0}; 
        double n1[3] = {nx1 * cos1 - ny1 * sin1, nx1 * sin1 + ny1 * cos1, 0}; 
        double p2[3] = {x1 * cos2 - y1 * sin2, x1 * sin2 + y1 * cos2,0}; 
        double n2[3] = {nx1 * cos2 - ny1 * sin2, nx1 * sin2 + ny1 * cos2, 0}; 
        double p3[3] = {x2 * cos2 - y2 * sin2, x2 * sin2 + y2 * cos2, 0}; 
        double n3[3] = {nx2 * cos2, ny2, nx2 * -sin2}; 
        double p4[3] = {x2 * cos1 - ny2 * sin1, x2 * sin1 + y2 * cos1, 0}; 
        double n4[3] = {nx2 * cos1 - ny2 * sin1,  nx2 * sin1 + ny2 * cos1, 0}; */
        
        glBegin(GL_QUADS);
		   
		   // glTranslatef(0,0,5);
            glNormal3dv(n1);
            glTexCoord2d(double(i) / N, t1);
            glVertex3dv(p1);
            glNormal3dv(n2);
           glTexCoord2d(double(i+1) / N, t1);
            glVertex3dv(p2);
            glNormal3dv(n3);
            glTexCoord2d(double(i+1) / N, t2);
            glVertex3dv(p3);
            glNormal3dv(n4);
            glTexCoord2d(double(i) / N, t2);
            glVertex3dv(p4);
        glEnd();
    }

    glDisable(GL_TEXTURE_2D);
}


// Draw just calls the display list we set up earlier.
void
Sweep::Draw(void)
{
    
	//glColor3f(1,0,0);
	glScalef(0.005,0.005,0.005);
	

	glRotatef(90,0,1,0);
    glRotatef(-30,1,0,0);
	glRotatef(90,0,0,1);
    glTranslatef(250,-250,-250);
	glPushMatrix();
	 for(int i = 0 ; i <= pointsNum ; i++){
    float angle =TWO_PI /pointsNum * i;
	if(i % 2 == 0){
		glColor3f(0,1,0);
		points[i].x[0] = cos(angle) * 100 ;
		points[i].x[1] = sin(angle) * 100 ;
		points[i].x[2] = 0;
	}
	else{
		glColor3f(1,1,1);
		points[i].x[0] = cos(angle) * 50;
		points[i].x[1] = sin(angle) * 50;
		points[i].x[2] = 0;
	}
  }
	 for(int i = 0;i < 3; i++){
		 drawStar(10,10,points,3);
		 glTranslatef(0,i,0);
	 }
   /* for(int j=0;  j<8;  j++)
    {    
		 DrawSegmentTextured(list[j][0], list[j][1],
            list[j][2], list[j][3],
            list[j+1][0], list[j+1][1],
            list[j+1][2], list[j+1][3]);
        DrawSegmentTextured(list[j][0], list[j][1],
            list[j][2], list[j][3],
            list[j+1][0], list[j+1][1],
            list[j+1][2], list[j+1][3],
            0.666 + double(j) / 8 * 0.333, 
            0.666 + double(j+1) / 8 * 0.333);
    }*/
    glPopMatrix();
}


