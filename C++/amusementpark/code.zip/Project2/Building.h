
#ifndef _BUILDING_H_
#define _BUILDING_H_

#include <Fl/gl.h>

class Building {
  private:
    GLubyte display_list;   // The display list that does all the work.
    GLuint  texture_obj[2];    // The object for the grass texture.
    bool    initialized;    // Whether or not we have been initialised.

  public:
    // Constructor. Can't do initialization here because we are
    // created before the OpenGL context is set up.
    Building(void) { display_list = 0; initialized = false; };

    // Destructor. Frees the display lists and texture object.
    ~Building(void);

    // Initializer. Creates the display list.
    bool    Initialize(void);

    // Does the drawing.
    void    Draw(void);
};


#endif
