
#include "Building.h"
#include "libtarga.h"
#include <stdio.h>
#include <GL/glu.h>

// Destructor
Building::~Building(void)
{
    if ( initialized )
    {
	glDeleteLists(display_list, 1);
	glDeleteTextures(1, &texture_obj[0]);
	glDeleteTextures(1, &texture_obj[1]);
    }
}


// Initializer. Returns false if something went wrong, like not being able to
// load the texture.
bool
Building::Initialize(void)
{
    ubyte   *image_data[2];
	char *images[] = {"roof.tga", "building.tga"};
	//ubyte   *roof_data;
    int	    image_height[2], image_width[2];

    // Load the image for the texture. The texture file has to be in
    // a place where it will be found.
	for(int i=0;i<2;i++){
       if ( ! ( image_data[i] = (ubyte*)tga_load(images[i], &image_width[i],
					   &image_height[i], TGA_TRUECOLOR_24) ) )
       {
	     fprintf(stderr, "Building::Initialize: Couldn't load roof.tga\n");
	     return false;
       }

    // This creates a texture object and binds it, so the next few operations
    // apply to this texture.
       glGenTextures(1, &texture_obj[i]);
       glBindTexture(GL_TEXTURE_2D, texture_obj[i]);

    // This sets a parameter for how the texture is loaded and interpreted.
    // basically, it says that the data is packed tightly in the image array.
       glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    // This sets up the texture with high quality filtering. First it builds
    // mipmaps from the image data, then it sets the filtering parameters
    // and the wrapping parameters. We want the grass to be repeated over the
    // ground.
       gluBuild2DMipmaps(GL_TEXTURE_2D,3, image_width[i], image_height[i], 
		          GL_RGB, GL_UNSIGNED_BYTE, image_data[i]);
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
       glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
		         GL_NEAREST_MIPMAP_LINEAR);

    // This says what to do with the texture. Modulate will multiply the
    // texture by the underlying color.
       glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); 
       
	   free(image_data[i]);
	}
    // Now do the geometry. Create the display list.
    display_list = glGenLists(1);
    glNewList(display_list, GL_COMPILE);
	// Use white, because the texture supplies the color.
	glColor3f(1.0, 1.0, 1.0);

	// The surface normal is up for the ground.
	glNormal3f(0.0, 0.0, 1.0);

	// Turn on texturing and bind the grass texture.
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texture_obj[0]);

	// Draw the ground as a quadrilateral, specifying texture coordinates.
	glBegin(GL_QUADS);
	  /*  glTexCoord2f(100.0, 100.0);
	    glVertex3f(50.0, 50.0, 0.0);
	    glTexCoord2f(-100.0, 100.0);
	    glVertex3f(-50.0, 50.0, 0.0);
	    glTexCoord2f(-100.0, -100.0);
	    glVertex3f(-50.0, -50.0, 0.0);
	    glTexCoord2f(100.0, -100.0);
	    glVertex3f(50.0, -50.0, 0.0);*/

	    // Front Face
	    glBindTexture(GL_TEXTURE_2D, texture_obj[0]);
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-10.0f, -10.0f,  10.0f);	// Bottom Left Of The Texture and Quad
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 10.0f, -10.0f,  10.0f);	// Bottom Right Of The Texture and Quad
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 10.0f,  10.0f,  10.0f);	// Top Right Of The Texture and Quad
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-10.0f,  10.0f,  10.0f);	// Top Left Of The Texture and Quad
	glEnd();

		// Back Face

		glBindTexture(GL_TEXTURE_2D, texture_obj[1]);
	glBegin(GL_QUADS);
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-10.0f, -10.0f, 0.0f);	// Bottom Right Of The Texture and Quad
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-10.0f,  10.0f, -10.0f);	// Top Right Of The Texture and Quad
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 10.0f,  10.0f, -10.0f);	// Top Left Of The Texture and Quad
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 10.0f, -10.0f, -10.0f);	// Bottom Left Of The Texture and Quad
		// Top Face

		glTexCoord2f(0.0f, 1.0f); glVertex3f(-10.0f,  10.0f, -10.0f);	// Top Left Of The Texture and Quad
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-10.0f,  10.0f,  10.0f);	// Bottom Left Of The Texture and Quad
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 10.0f,  10.0f,  10.0f);	// Bottom Right Of The Texture and Quad
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 10.0f,  10.0f, -10.0f);	// Top Right Of The Texture and Quad
		// Bottom Face
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-10.0f, -10.0f, -10.0f);	// Top Right Of The Texture and Quad
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 10.0f, -10.0f, -10.0f);	// Top Left Of The Texture and Quad
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 10.0f, -10.0f,  10.0f);	// Bottom Left Of The Texture and Quad
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-10.0f, -10.0f,  10.0f);	// Bottom Right Of The Texture and Quad
		// Right face
		glTexCoord2f(1.0f, 0.0f); glVertex3f( 10.0f, -10.0f, -10.0f);	// Bottom Right Of The Texture and Quad
		glTexCoord2f(1.0f, 1.0f); glVertex3f( 10.0f,  10.0f, -10.0f);	// Top Right Of The Texture and Quad
		glTexCoord2f(0.0f, 1.0f); glVertex3f( 10.0f,  10.0f,  10.0f);	// Top Left Of The Texture and Quad
		glTexCoord2f(0.0f, 0.0f); glVertex3f( 10.0f, -10.0f,  10.0f);	// Bottom Left Of The Texture and Quad
		// Left Face
		glTexCoord2f(0.0f, 0.0f); glVertex3f(-10.0f, -10.0f, -10.0f);	// Bottom Left Of The Texture and Quad
		glTexCoord2f(1.0f, 0.0f); glVertex3f(-10.0f, -10.0f,  10.0f);	// Bottom Right Of The Texture and Quad
		glTexCoord2f(1.0f, 1.0f); glVertex3f(-10.0f,  10.0f,  10.0f);	// Top Right Of The Texture and Quad
		glTexCoord2f(0.0f, 1.0f); glVertex3f(-10.0f,  10.0f, -10.0f);	// Top Left Of The Texture and Quad
	glEnd();

	// Turn texturing off again, because we don't want everything else to
	// be textured.
	glDisable(GL_TEXTURE_2D);
    glEndList();

    // We only do all this stuff once, when the GL context is first set up.
    initialized = true;

    return true;
}


// Draw just calls the display list we set up earlier.
void
Building::Draw(void)
{
    glPushMatrix();
	glTranslatef(30,30,0);
    glCallList(display_list);
    glPopMatrix();
}


