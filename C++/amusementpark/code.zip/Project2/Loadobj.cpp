/*
 * Ground.cpp: A class for drawing the ground.
 *
 * (c) 2001-2002: Stephen Chenney, University of Wisconsin at Madison.
 */


#include "Loadobj.h"
//#include "libtarga.h"
#include "Texture.h"
#include <stdio.h>
#include <GL/glu.h>
#include "glm.h"

GLMmodel* pmodel1 = NULL;

GLuint texture;
Texture treeTexture;

bool LoadTreeTextures()
{
// first of all we call the tga file loader. It doesn't do anything special: it fills the Texture struct with information about
// the image (height, width, bits per pixel). You can easily replace it with a function to load bmps or jpegs.
// The important thing is do load the image corectly in the structure you give it
if (LoadTGA(&treeTexture, "Liberty.tga")) 
{ 
// This tells opengl to create 1 texture and put it's ID in the given integer variable
// OpenGL keeps a track of loaded textures by numbering them: the first one you load is 1, second is 2, ...and so on.
glGenTextures(1, &treeTexture.texID);
// Binding the texture to GL_TEXTURE_2D is like telling OpenGL that the texture with this ID is now the current 2D texture in use
// If you draw anything the used texture will be the last binded texture
glBindTexture(GL_TEXTURE_2D, treeTexture.texID);
// This call will actualy load the image data into OpenGL and your video card's memory. The texture is allways loaded into the current texture
// you have selected with the last glBindTexture call
// It asks for the width, height, type of image (determins the format of the data you are giveing to it) and the pointer to the actual data
glTexImage2D(GL_TEXTURE_2D, 0, treeTexture.bpp / 8, treeTexture.width, treeTexture.height, 0, treeTexture.type, GL_UNSIGNED_BYTE, treeTexture.imageData);

glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
glEnable(GL_TEXTURE_2D);
if (treeTexture.imageData) 
{
// You can now free the image data that was allocated by LoadTGA
// You don't want to keep a few Mb of worthless data on heap. It's worthless because OpenGL stores the image someware else after
// you call glTexImage2D (usualy in you video card)
free(treeTexture.imageData);
}
return true; 
} // Return The Status
else return false;
}

// Destructor
Loadobj::~Loadobj(void)
{
	
}


// Initializer. Returns false if something went wrong, like not being able to
// load the texture.
bool
Loadobj::Initialize(void)
{
  //  glClearColor (0.0, 0.0, 0.0, 0.0);
//LoadTreeTextures();
//glEnable(GL_DEPTH_TEST);
//glShadeModel (GL_SMOOTH);

	/*ubyte   *image_data;
    int	    image_height, image_width;

    // Load the image for the texture. The texture file has to be in
    // a place where it will be found.
    if ( ! ( image_data = (ubyte*)tga_load("Liberty.tga", &image_width,
					   &image_height, TGA_TRUECOLOR_24) ) )
    {
	fprintf(stderr, "Ground::Initialize: Couldn't load grass.tga\n");
	return false;
    }

    // This creates a texture object and binds it, so the next few operations
    // apply to this texture.
    glGenTextures(1, &texture_obj);
    glBindTexture(GL_TEXTURE_2D, texture_obj);

    // This sets a parameter for how the texture is loaded and interpreted.
    // basically, it says that the data is packed tightly in the image array.
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    // This sets up the texture with high quality filtering. First it builds
    // mipmaps from the image data, then it sets the filtering parameters
    // and the wrapping parameters. We want the grass to be repeated over the
    // ground.
    gluBuild2DMipmaps(GL_TEXTURE_2D,3, image_width, image_height, 
		      GL_RGB, GL_UNSIGNED_BYTE, image_data);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER,
		    GL_NEAREST_MIPMAP_LINEAR);

    // This says what to do with the texture. Modulate will multiply the
    // texture by the underlying color.
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); 

	free(image_data);*/
	return true;
}


// Draw just calls the display list we set up earlier.
void
Loadobj::Draw(void)
{
	glColor3f(1,1,1);
	glTranslatef(0,0,10);
	glRotatef(90,1,0,0);
	glRotatef(0,0,1,0);
	glScalef(15,15,15); 
	if (!pmodel1) 
	{
		// this is the call that actualy reads the OBJ and creates the model object      
		pmodel1 = glmReadOBJ("Liberty.obj");	
        if (!pmodel1) exit(0);
		// This will rescale the object to fit into the unity matrix
		// Depending on your project you might want to keep the original size and positions you had in 3DS Max or GMAX so you may have to comment this.
        glmUnitize(pmodel1);
		// These 2 functions calculate triangle and vertex normals from the geometry data.
		// To be honest I had some problem with very complex models that didn't look to good because of how vertex normals were calculated
		// So if you can export these directly from you modeling tool do it and comment these line
		// 3DS Max can calculate these for you and GLM is perfectly capable of loading them
        glmFacetNormals(pmodel1);        
		glmVertexNormals(pmodel1, 90.0);
    }
    // before you draw anything you should bind the right texture
    // If you have more then one texture you will have to make sure you bind the right one
	//glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, treeTexture.texID);
    // You can replace this with your drawing code
    // This calls GLM to draw the loaded model with GLM_TEXTURE on to tell it to also render texture coordinates
    // without those coordinates OpenGL will have no ideea how to map your texture to the object
     glmDraw(pmodel1, GLM_SMOOTH );
	//glmDraw(pmodel1, GLM_SMOOTH | GLM_MATERIAL | GLM_TEXTURE);
 
}


